Oakline logo pack, v3 (October).

Use the full-colour wordmark on light backgrounds and the reversed one on dark.
Keep clear space of one mark-height on every side. Never stretch, recolour or outline it.
The mark on its own is for avatars and favicons only.

Questions: avery@oakline.example
